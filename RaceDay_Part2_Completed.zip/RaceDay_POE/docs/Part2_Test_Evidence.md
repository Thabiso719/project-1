# RaceDay Part 2 – Test Evidence Plan

## Automated tests

The `RaceDay.Tests` project contains tests for:

1. Password hashing and password verification.
2. Successful registration and login.
3. Login failure with an incorrect password.
4. Participant rejection from organiser-only event creation.
5. Organiser permission to create an event.
6. Participant enrolment and retrieval of own enrolments.

## Manual Swagger evidence to capture

Use Swagger after starting the API and capture genuine screenshots showing:

- Swagger endpoint list.
- Participant registration and login.
- Organiser login and event creation.
- Participant attempt to create an event returning `403 Forbidden`.
- Category creation.
- Participant enrolment.
- Organiser enrolment listing/status update.
- Organiser result capture.
- Participant result retrieval.
- Logout.

## GitHub Actions evidence

After pushing the project to the student's GitHub repository, capture a screenshot of the actual successful green `RaceDay Build and Test` workflow run. The screenshot should show the repository, workflow name and successful build/test status.
