/* ============================================================
   RaceDay Part 1 - SQL Server Database Script
   ============================================================ */

IF DB_ID('RaceDayDB') IS NOT NULL
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END;
GO

CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO

CREATE TABLE Users
(
    UserID INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(150) NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
    PasswordHash VARCHAR(500) NOT NULL,
    Role VARCHAR(20) NOT NULL,
    PhoneNumber VARCHAR(30) NULL,
    ProfilePictureUrl VARCHAR(500) NULL,
    CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Users_Role CHECK (Role IN ('Organiser','Participant'))
);
GO

CREATE TABLE Events
(
    EventID INT IDENTITY(1,1) CONSTRAINT PK_Events PRIMARY KEY,
    OrganiserID INT NOT NULL,
    Name VARCHAR(150) NOT NULL,
    Description VARCHAR(1000) NOT NULL,
    EventDate DATETIME2 NOT NULL,
    Location VARCHAR(200) NOT NULL,
    Distance DECIMAL(7,2) NOT NULL,
    EventType VARCHAR(20) NOT NULL,
    BannerImageUrl VARCHAR(500) NULL,
    CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Events_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Events_Organiser FOREIGN KEY (OrganiserID) REFERENCES Users(UserID),
    CONSTRAINT CK_Events_Distance CHECK (Distance > 0),
    CONSTRAINT CK_Events_Type CHECK (EventType IN ('Run','Walk','Cycle'))
);
GO

CREATE TABLE Categories
(
    CategoryID INT IDENTITY(1,1) CONSTRAINT PK_Categories PRIMARY KEY,
    EventID INT NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Description VARCHAR(255) NULL,
    CONSTRAINT FK_Categories_Event FOREIGN KEY (EventID) REFERENCES Events(EventID) ON DELETE CASCADE,
    CONSTRAINT UQ_Categories_Event_Name UNIQUE (EventID, Name),
    CONSTRAINT UQ_Categories_Event_Category UNIQUE (EventID, CategoryID)
);
GO

CREATE TABLE Enrolments
(
    EnrolmentID INT IDENTITY(1,1) CONSTRAINT PK_Enrolments PRIMARY KEY,
    ParticipantID INT NOT NULL,
    EventID INT NOT NULL,
    CategoryID INT NOT NULL,
    EnrolmentDate DATETIME2 NOT NULL CONSTRAINT DF_Enrolments_Date DEFAULT SYSUTCDATETIME(),
    Status VARCHAR(20) NOT NULL CONSTRAINT DF_Enrolments_Status DEFAULT 'Pending',
    CONSTRAINT FK_Enrolments_Participant FOREIGN KEY (ParticipantID) REFERENCES Users(UserID),
    CONSTRAINT FK_Enrolments_Event FOREIGN KEY (EventID) REFERENCES Events(EventID) ON DELETE CASCADE,
    CONSTRAINT FK_Enrolments_CategoryForEvent FOREIGN KEY (EventID, CategoryID)
        REFERENCES Categories(EventID, CategoryID),
    CONSTRAINT UQ_Enrolments_Participant_Event UNIQUE (ParticipantID, EventID),
    CONSTRAINT CK_Enrolments_Status CHECK (Status IN ('Pending','Confirmed','Cancelled'))
);
GO

CREATE TABLE Results
(
    ResultID INT IDENTITY(1,1) CONSTRAINT PK_Results PRIMARY KEY,
    EnrolmentID INT NOT NULL CONSTRAINT UQ_Results_Enrolment UNIQUE,
    FinishTime TIME NOT NULL,
    FinishingPosition INT NOT NULL,
    CreatedAt DATETIME2 NOT NULL CONSTRAINT DF_Results_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_Results_Enrolment FOREIGN KEY (EnrolmentID) REFERENCES Enrolments(EnrolmentID) ON DELETE CASCADE,
    CONSTRAINT CK_Results_Position CHECK (FinishingPosition > 0)
);
GO

INSERT INTO Users (FirstName,LastName,Email,PasswordHash,Role,PhoneNumber)
VALUES
('Thabo','Mokoena','thabo.organiser@raceday.co.za','SEED-HASH-CHANGE-IN-APP','Organiser','0711111111'),
('Nomsa','Dlamini','nomsa.organiser@raceday.co.za','SEED-HASH-CHANGE-IN-APP','Organiser','0722222222'),
('Sipho','Nkosi','sipho.participant@raceday.co.za','SEED-HASH-CHANGE-IN-APP','Participant','0733333333'),
('Lerato','Molefe','lerato.participant@raceday.co.za','SEED-HASH-CHANGE-IN-APP','Participant','0744444444');
GO

INSERT INTO Events (OrganiserID,Name,Description,EventDate,Location,Distance,EventType)
VALUES
(1,'Johannesburg City Run','A road running event through Johannesburg.','2027-03-14T07:00:00','Johannesburg, Gauteng',21.10,'Run'),
(1,'Soweto Community Walk','A community walking event promoting health and fitness.','2027-04-18T08:00:00','Soweto, Gauteng',10.00,'Walk'),
(2,'Pretoria Cycle Challenge','A cycling event for recreational and competitive cyclists.','2027-05-09T06:30:00','Pretoria, Gauteng',40.00,'Cycle');
GO

INSERT INTO Categories (EventID,Name,Description)
VALUES
(1,'Under 20','Participants younger than 20 years.'),
(1,'Senior','Open senior category.'),
(1,'Veteran','Veteran participant category.'),
(2,'10 km Open','Open 10 kilometre walking category.'),
(2,'Family Walk','Category for family participants.'),
(3,'40 km Open','Open 40 kilometre cycling category.'),
(3,'Junior','Junior cycling category.');
GO

INSERT INTO Enrolments (ParticipantID,EventID,CategoryID,Status)
VALUES
(3,1,2,'Confirmed'),
(4,1,2,'Confirmed'),
(3,2,4,'Confirmed'),
(4,3,6,'Pending');
GO

INSERT INTO Results (EnrolmentID,FinishTime,FinishingPosition)
VALUES
(1,'02:14:32',47),
(2,'02:21:45',68);
GO

SELECT U.FirstName + ' ' + U.LastName AS Participant,
       E.Name AS EventName,
       E.EventDate,
       C.Name AS Category,
       EN.Status AS EnrolmentStatus,
       R.FinishTime,
       R.FinishingPosition
FROM Enrolments EN
JOIN Users U ON EN.ParticipantID = U.UserID
JOIN Events E ON EN.EventID = E.EventID
JOIN Categories C ON EN.EventID = C.EventID AND EN.CategoryID = C.CategoryID
LEFT JOIN Results R ON EN.EnrolmentID = R.EnrolmentID
ORDER BY E.EventDate;
GO
