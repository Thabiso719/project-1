# Part 1 – IEEE References

[1] R. T. Fielding, *Architectural Styles and the Design of Network-based Software Architectures*, Ph.D. dissertation, University of California, Irvine, 2000.

[2] OWASP Foundation, “Password Storage Cheat Sheet,” OWASP Cheat Sheet Series, accessed Sep. 3, 2026.

[3] Microsoft, “ASP.NET Core documentation,” Microsoft Learn, accessed Sep. 3, 2026.

[4] Microsoft, “Entity Framework Core documentation,” Microsoft Learn, accessed Sep. 3, 2026.

## Example in-text use

REST is an architectural style intended to support scalable network-based applications [1]. Passwords should be protected using an appropriate password-hashing approach rather than being stored in plaintext [2].
