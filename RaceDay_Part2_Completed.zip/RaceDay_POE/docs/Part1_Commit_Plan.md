# Part 1 – Meaningful Commit Plan

Use your own GitHub account and make each commit after doing the corresponding work. Do not create fake commits.

1. `chore: create RaceDay repository structure`
2. `docs: add Part 1 requirements notes`
3. `docs: define RaceDay user roles`
4. `docs: design user entity`
5. `docs: design event entity`
6. `docs: design category entity`
7. `docs: design enrolment entity`
8. `docs: design result entity`
9. `docs: create initial ERD`
10. `docs: refine ERD relationships and cardinality`
11. `docs: add complete API endpoint plan`
12. `docs: review authentication endpoints`
13. `docs: review event and category endpoints`
14. `docs: review enrolment and result endpoints`
15. `sql: create RaceDay database schema`
16. `sql: add keys constraints and validation`
17. `sql: add realistic seed data`
18. `docs: add IEEE references and design notes`
19. `ci: add Part 1 repository validation workflow`
20. `docs: complete README and Part 1 submission checklist`
