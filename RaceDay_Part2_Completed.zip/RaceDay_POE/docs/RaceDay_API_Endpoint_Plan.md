# RaceDay API Endpoint Plan

All routes use the `/api/` prefix. This plan is the Part 1 specification for the Part 2 API.

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | `/api/auth/register` | Creates a new Organiser or Participant account. | Public | firstName, lastName, email, password, role, phoneNumber | 201 Created; 400 validation; 409 duplicate email |
| POST | `/api/auth/login` | Authenticates a user and creates an authenticated session. | Public | email, password | 200 OK; 401 invalid credentials |
| POST | `/api/auth/logout` | Ends the current authenticated session. | Any logged in | None | 204 No Content |
| GET | `/api/profile/me` | Returns the logged-in user's profile. | Any logged in | None | 200 OK; 401 unauthenticated |
| PUT | `/api/profile/me` | Updates the logged-in user's profile. | Any logged in | firstName, lastName, phoneNumber, profilePictureUrl | 200 OK; 400 validation |
| GET | `/api/events` | Lists events, optionally filtered by search/type/date. | Public | Query string | 200 OK |
| GET | `/api/events/{id}` | Returns one event and its information. | Public | None | 200 OK; 404 not found |
| POST | `/api/events` | Creates an event owned by the logged-in Organiser. | Organiser | name, description, eventDate, location, distance, eventType, bannerImageUrl | 201 Created; 400/401/403 |
| PUT | `/api/events/{id}` | Updates an event owned by the Organiser. | Organiser | Event fields | 200 OK; 403/404 |
| DELETE | `/api/events/{id}` | Deletes an event owned by the Organiser. | Organiser | None | 204; 403/404 |
| GET | `/api/events/{eventId}/categories` | Lists categories for an event. | Public | None | 200 OK |
| POST | `/api/events/{eventId}/categories` | Adds an age/distance category. | Organiser | name, description | 201 Created; 403/404 |
| PUT | `/api/categories/{id}` | Updates a category. | Organiser | name, description | 200 OK; 403/404 |
| DELETE | `/api/categories/{id}` | Deletes a category. | Organiser | None | 204; 403/404 |
| POST | `/api/enrolments` | Enrols the logged-in Participant in an event/category. | Participant | eventId, categoryId | 201 Created; 400/404/409 |
| GET | `/api/enrolments/my` | Returns the logged-in Participant's enrolments. | Participant | None | 200 OK |
| GET | `/api/events/{eventId}/enrolments` | Returns enrolments for an Organiser's event. | Organiser | None | 200 OK; 403/404 |
| PUT | `/api/enrolments/{id}/status` | Changes enrolment status. | Organiser | status | 200 OK; 403/404 |
| POST | `/api/results` | Captures a finish time and position for an enrolment. | Organiser | enrolmentId, finishTime, finishingPosition | 201 Created; 400/403/404 |
| GET | `/api/results/my` | Returns the Participant's personal race history. | Participant | None | 200 OK |
| GET | `/api/events/{eventId}/results` | Returns results for an Organiser's event. | Organiser | None | 200 OK; 403/404 |

## Design notes

The API follows resource-oriented REST conventions and separates authentication, profile, event, category, enrolment and result responsibilities. The route plan should be treated as the baseline for Part 2 implementation.
