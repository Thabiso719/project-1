# RaceDay Part 2 – Meaningful Commit Plan

The Part 2 brief requires at least 20 meaningful commits. These are suggested logical checkpoints, not fabricated commit history. The student should make and push their own commits while implementing and testing the project.

1. Start Part 2 API branch/folder.
2. Configure ASP.NET Core API and Swagger.
3. Configure SQL Server EF Core.
4. Align EF models with Part 1 Users table.
5. Align Event model and constraints.
6. Align Category and composite event/category relationship.
7. Align Enrolment and status constraints.
8. Align Result relationship and validation.
9. Implement password hashing.
10. Implement registration endpoint.
11. Implement session login/logout.
12. Implement profile endpoints.
13. Implement public event browsing/filtering.
14. Implement organiser event CRUD and ownership checks.
15. Implement category management.
16. Implement participant enrolments.
17. Implement organiser enrolment management.
18. Implement organiser result capture and participant result history.
19. Add Swagger descriptions and response metadata.
20. Add API integration tests.
21. Add EF migration and database setup documentation.
22. Update GitHub Actions build/test workflow.
23. Update README and test evidence documentation.
24. Final local build/test and bug-fix commit.
