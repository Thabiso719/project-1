# RaceDay – Part 2 RESTful API Development

RaceDay is a full-stack event-management system for South African road running, walking and cycling events. This repository continues the approved Part 1 design and implements the Part 2 RESTful API in ASP.NET Core Web API with C#, Entity Framework Core, SQL Server, session-based authentication, role enforcement, Swagger and automated tests.

> **Academic integrity:** This project contains development assistance and reference implementation material. Before submission, the student must review, understand, test and adapt the implementation and must make their own meaningful Git commits and record their own demonstration. The Part 2 brief requires AI-use disclosure where applicable.

## Roles

- **Organiser:** creates, updates and deletes owned events; manages event categories; views enrolments; confirms/cancels enrolments; captures results.
- **Participant:** registers/logs in; manages own profile; views events/categories; enrols in events; views own enrolments and results.

## Solution structure

```text
RaceDay/
├── docs/
│   ├── RaceDay_ERD.png
│   ├── RaceDay_API_Endpoint_Plan.md
│   ├── RaceDay_Database.sql
│   ├── Part1_IEEE_References.md
│   ├── Part1_Commit_Plan.md
│   ├── Part2_Test_Evidence.md
│   └── Part2_Commit_Plan.md
├── RaceDay.Api/
│   ├── Controllers/
│   ├── Data/
│   ├── DTOs/
│   ├── Migrations/
│   ├── Models/
│   └── Services/
├── RaceDay.Mvc/
├── RaceDay.Tests/
├── .github/workflows/
├── Dockerfile
└── RaceDay.sln
```

## Part 2 requirements implemented

1. ASP.NET Core Web API targeting .NET 8.
2. Entity Framework Core with SQL Server and Code-First migration support.
3. Session-based authentication storing the authenticated user ID and role in server-side session state.
4. PBKDF2-SHA256 password hashing with a unique random salt; plaintext passwords are never stored.
5. Organiser/Participant role enforcement on protected endpoints.
6. Profile, event, category, enrolment and result functionality from the Part 1 endpoint plan.
7. Swagger/OpenAPI documentation at `/swagger`.
8. Unit/integration tests covering registration, login failure, role rejection, organiser event creation and participant enrolment.
9. GitHub Actions workflow for restore, build and test.

## SQL Server setup

### Option A – Code First (recommended for Part 2)

1. Install SQL Server and SQL Server Management Studio (SSMS).
2. Create an empty SQL Server database named `RaceDayDB`, or allow the EF migration to create the schema.
3. Set `RaceDay.Api/appsettings.json` or an environment variable:

```text
ConnectionStrings__DefaultConnection=Server=localhost;Database=RaceDayDB;Trusted_Connection=True;TrustServerCertificate=True;
```

4. From the solution folder run:

```bash
dotnet restore
dotnet build
dotnet ef database update --project RaceDay.Api
```

If the migration tooling is not installed:

```bash
dotnet tool install --global dotnet-ef --version 8.*
```

### Option B – Part 1 SQL script

The original approved Part 1 SQL remains in `docs/RaceDay_Database.sql` and can be run in SSMS on a clean SQL Server instance.

## Seed accounts

When the database is empty, the API seeds the Part 1 sample data. The seeded accounts use the password `RaceDay!2026`:

- `thabo.organiser@raceday.co.za` – Organiser
- `nomsa.organiser@raceday.co.za` – Organiser
- `sipho.participant@raceday.co.za` – Participant
- `lerato.participant@raceday.co.za` – Participant

## Run the API

From the solution folder:

```bash
dotnet restore
dotnet build
dotnet run --project RaceDay.Api
```

Open Swagger using the HTTPS URL printed by Visual Studio/.NET, then add `/swagger`.

## Authentication flow in Swagger

1. Register a Participant or Organiser using `POST /api/auth/register`.
2. Login using `POST /api/auth/login`.
3. The API creates a session cookie containing the authenticated session identifier.
4. Use the protected endpoints in the same browser session.
5. Use `POST /api/auth/logout` to clear the session.

## Main API endpoints

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public |
| POST | `/api/auth/login` | Public |
| POST | `/api/auth/logout` | Authenticated |
| GET/PUT | `/api/profile/me` | Authenticated |
| GET | `/api/events` | Public |
| GET | `/api/events/{id}` | Public |
| POST/PUT/DELETE | `/api/events/{id}` | Organiser/owner |
| GET | `/api/events/{eventId}/categories` | Public |
| POST | `/api/events/{eventId}/categories` | Organiser/owner |
| PUT/DELETE | `/api/categories/{id}` | Organiser/owner |
| POST | `/api/enrolments` | Participant |
| GET | `/api/enrolments/my` | Participant |
| GET | `/api/events/{eventId}/enrolments` | Organiser/owner |
| PUT | `/api/enrolments/{id}/status` | Organiser/owner |
| POST | `/api/results` | Organiser/owner |
| GET | `/api/results/my` | Participant |
| GET | `/api/events/{eventId}/results` | Organiser/owner |

## Run tests

```bash
dotnet test --configuration Release
```

The test suite uses EF Core InMemory for isolated API integration tests, so the tests do not require a local SQL Server database.

## Azure Blob Storage

The API includes the Part 3-compatible image upload service. Configure:

```text
Azure__BlobConnectionString=<your Azure Blob Storage connection string>
Azure__ContainerName=raceday-images
```

Do not commit real Azure connection strings or other secrets to GitHub.

## GitHub Actions

`.github/workflows/build-test.yml` restores packages, builds the solution and runs the test suite on pushes and pull requests.

`.github/workflows/part1-validation.yml` validates the required Part 1 documentation files.

## Evidence that must be completed by the student

The following cannot be truthfully generated on the student's behalf:

- the student's own GitHub repository URL;
- the minimum 20 meaningful Part 2 commits made from the student's GitHub account;
- a genuine green GitHub Actions screenshot from that repository;
- the student's unlisted YouTube demonstration and voiceover.

Add those genuine items to the README/ARC before submission. Do not fabricate screenshots, commit history or a video link.
