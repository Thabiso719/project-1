using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Controllers;

public class HomeController : Controller
{
    private readonly IHttpClientFactory _factory;
    public HomeController(IHttpClientFactory factory)=>_factory=factory;

    public async Task<IActionResult> Index()
    {
        var client=_factory.CreateClient("RaceDayApi");
        var response=await client.GetAsync("/api/events");
        if(!response.IsSuccessStatusCode) return View(new List<EventViewModel>());
        var json=await response.Content.ReadAsStringAsync();
        var events=JsonSerializer.Deserialize<List<EventViewModel>>(json,new JsonSerializerOptions{PropertyNameCaseInsensitive=true}) ?? new();
        return View(events);
    }
}
