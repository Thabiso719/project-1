using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Controllers;

public class AccountController : Controller
{
    private readonly IHttpClientFactory _factory;
    public AccountController(IHttpClientFactory factory)=>_factory=factory;

    [HttpGet] public IActionResult Login()=>View();
    [HttpPost] public async Task<IActionResult> Login(LoginViewModel model)
    {
        if(!ModelState.IsValid) return View(model);
        var client=_factory.CreateClient("RaceDayApi");
        var response=await client.PostAsJsonAsync("/api/auth/login",model);
        if(!response.IsSuccessStatusCode){ModelState.AddModelError("","Invalid email or password.");return View(model);}
        var user=await response.Content.ReadFromJsonAsync<UserSession>();
        HttpContext.Session.SetInt32("UserId",user!.UserID);
        HttpContext.Session.SetString("Role",user.Role);
        HttpContext.Session.SetString("Name",user.FirstName);
        return RedirectToAction("Index","Home");
    }

    [HttpGet] public IActionResult Register()=>View();
    [HttpPost] public async Task<IActionResult> Register(RegisterViewModel model)
    {
        var client=_factory.CreateClient("RaceDayApi");
        var response=await client.PostAsJsonAsync("/api/auth/register",model);
        if(!response.IsSuccessStatusCode){ModelState.AddModelError("","Registration failed.");return View(model);}
        return RedirectToAction("Login");
    }

    public IActionResult Logout(){HttpContext.Session.Clear();return RedirectToAction("Index","Home");}
    private record UserSession(int UserID,string FirstName,string LastName,string Email,string Role,string? PhoneNumber,string? ProfilePictureUrl);
}
