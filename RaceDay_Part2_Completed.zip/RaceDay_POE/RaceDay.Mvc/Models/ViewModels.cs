namespace RaceDay.Mvc.Models;

public class LoginViewModel { public string Email {get;set;}=""; public string Password {get;set;}=""; }
public class RegisterViewModel { public string FirstName {get;set;}=""; public string LastName {get;set;}=""; public string Email {get;set;}=""; public string Password {get;set;}=""; public string Role {get;set;}="Participant"; public string? PhoneNumber {get;set;} }
public class EventViewModel { public int EventID {get;set;} public int OrganiserID {get;set;} public string Name {get;set;}=""; public string Description {get;set;}=""; public DateTime EventDate {get;set;} public string Location {get;set;}=""; public decimal Distance {get;set;} public string EventType {get;set;}="Run"; public string? BannerImageUrl {get;set;} }
