using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RaceDay.Api.Migrations;

public partial class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Users",
            columns: table => new
            {
                UserID = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                FirstName = table.Column<string>(maxLength: 50, nullable: false),
                LastName = table.Column<string>(maxLength: 50, nullable: false),
                Email = table.Column<string>(maxLength: 150, nullable: false),
                PasswordHash = table.Column<string>(maxLength: 500, nullable: false),
                Role = table.Column<string>(maxLength: 20, nullable: false),
                PhoneNumber = table.Column<string>(maxLength: 30, nullable: true),
                ProfilePictureUrl = table.Column<string>(maxLength: 500, nullable: true),
                CreatedAt = table.Column<DateTime>(nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Users", x => x.UserID);
                table.CheckConstraint("CK_Users_Role", "[Role] IN ('Organiser','Participant')");
            });

        migrationBuilder.CreateTable(
            name: "Events",
            columns: table => new
            {
                EventID = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                OrganiserID = table.Column<int>(nullable: false),
                Name = table.Column<string>(maxLength: 150, nullable: false),
                Description = table.Column<string>(maxLength: 1000, nullable: false),
                EventDate = table.Column<DateTime>(nullable: false),
                Location = table.Column<string>(maxLength: 200, nullable: false),
                Distance = table.Column<decimal>(type: "decimal(7,2)", nullable: false),
                EventType = table.Column<string>(maxLength: 20, nullable: false),
                BannerImageUrl = table.Column<string>(maxLength: 500, nullable: true),
                CreatedAt = table.Column<DateTime>(nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Events", x => x.EventID);
                table.CheckConstraint("CK_Events_Distance", "[Distance] > 0");
                table.ForeignKey("FK_Events_Organiser", x => x.OrganiserID, "Users", "UserID", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "Categories",
            columns: table => new
            {
                CategoryID = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                EventID = table.Column<int>(nullable: false),
                Name = table.Column<string>(maxLength: 100, nullable: false),
                Description = table.Column<string>(maxLength: 255, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Categories", x => x.CategoryID);
                table.ForeignKey("FK_Categories_Event", x => x.EventID, "Events", "EventID", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "Enrolments",
            columns: table => new
            {
                EnrolmentID = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                ParticipantID = table.Column<int>(nullable: false),
                EventID = table.Column<int>(nullable: false),
                CategoryID = table.Column<int>(nullable: false),
                EnrolmentDate = table.Column<DateTime>(nullable: false),
                Status = table.Column<string>(maxLength: 20, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Enrolments", x => x.EnrolmentID);
                table.ForeignKey("FK_Enrolments_Participant", x => x.ParticipantID, "Users", "UserID", onDelete: ReferentialAction.Restrict);
                table.ForeignKey("FK_Enrolments_Event", x => x.EventID, "Events", "EventID", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateTable(
            name: "Results",
            columns: table => new
            {
                ResultID = table.Column<int>(nullable: false).Annotation("SqlServer:Identity", "1, 1"),
                EnrolmentID = table.Column<int>(nullable: false),
                FinishTime = table.Column<TimeSpan>(nullable: false),
                FinishingPosition = table.Column<int>(nullable: false),
                CreatedAt = table.Column<DateTime>(nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Results", x => x.ResultID);
                table.ForeignKey("FK_Results_Enrolment", x => x.EnrolmentID, "Enrolments", "EnrolmentID", onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex(name: "UQ_Users_Email", table: "Users", column: "Email", unique: true);
        migrationBuilder.CreateIndex(name: "IX_Events_OrganiserID", table: "Events", column: "OrganiserID");
        migrationBuilder.CreateIndex(name: "UQ_Categories_Event_Name", table: "Categories", columns: new[] { "EventID", "Name" }, unique: true);
        migrationBuilder.CreateIndex(name: "UQ_Categories_Event_Category", table: "Categories", columns: new[] { "EventID", "CategoryID" }, unique: true);
        migrationBuilder.CreateIndex(name: "IX_Enrolments_ParticipantID", table: "Enrolments", column: "ParticipantID");
        migrationBuilder.CreateIndex(name: "UQ_Enrolments_Participant_Event", table: "Enrolments", columns: new[] { "ParticipantID", "EventID" }, unique: true);
        migrationBuilder.CreateIndex(name: "IX_Enrolments_EventID_CategoryID", table: "Enrolments", columns: new[] { "EventID", "CategoryID" });
        migrationBuilder.CreateIndex(name: "UQ_Results_Enrolment", table: "Results", column: "EnrolmentID", unique: true);

        migrationBuilder.AddForeignKey(
            name: "FK_Enrolments_CategoryForEvent",
            table: "Enrolments",
            columns: new[] { "EventID", "CategoryID" },
            principalTable: "Categories",
            principalColumns: new[] { "EventID", "CategoryID" },
            onDelete: ReferentialAction.Restrict);

        migrationBuilder.AddCheckConstraint("CK_Events_Type", "Events", "[EventType] IN ('Run','Walk','Cycle')");
        migrationBuilder.AddCheckConstraint("CK_Enrolments_Status", "Enrolments", "[Status] IN ('Pending','Confirmed','Cancelled')");
        migrationBuilder.AddCheckConstraint("CK_Results_Position", "Results", "[FinishingPosition] > 0");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "Results");
        migrationBuilder.DropTable(name: "Enrolments");
        migrationBuilder.DropTable(name: "Categories");
        migrationBuilder.DropTable(name: "Events");
        migrationBuilder.DropTable(name: "Users");
    }
}
