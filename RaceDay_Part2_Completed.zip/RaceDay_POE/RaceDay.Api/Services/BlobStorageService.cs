using Azure.Storage.Blobs;

namespace RaceDay.Api.Services;

public class BlobStorageService
{
    private readonly IConfiguration _configuration;
    public BlobStorageService(IConfiguration configuration) => _configuration = configuration;

    public async Task<string?> UploadAsync(IFormFile file)
    {
        var connection = _configuration["Azure:BlobConnectionString"];
        var containerName = _configuration["Azure:ContainerName"] ?? "raceday-images";
        if (string.IsNullOrWhiteSpace(connection))
            return null;

        var container = new BlobContainerClient(connection, containerName);
        await container.CreateIfNotExistsAsync();
        var blobName = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName)}";
        var blob = container.GetBlobClient(blobName);
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, overwrite: true);
        return blob.Uri.ToString();
    }
}
