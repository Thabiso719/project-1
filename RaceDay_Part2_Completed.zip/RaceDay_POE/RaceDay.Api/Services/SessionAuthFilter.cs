using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Api.Services;

public class SessionAuthFilter : IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
    {
        var userId = context.HttpContext.Session.GetInt32("UserId");
        if (userId is null)
        {
            context.Result = new UnauthorizedObjectResult(new { message = "Authentication required." });
            return;
        }
        await next();
    }

    public static int? UserId(HttpContext context) => context.Session.GetInt32("UserId");
    public static string? Role(HttpContext context) => context.Session.GetString("Role");
}
