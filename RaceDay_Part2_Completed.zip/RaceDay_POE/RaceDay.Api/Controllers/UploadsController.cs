using Microsoft.AspNetCore.Mvc;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/uploads")]
[ServiceFilter(typeof(SessionAuthFilter))]
public class UploadsController : ControllerBase
{
    private readonly BlobStorageService _blob;
    public UploadsController(BlobStorageService blob) => _blob = blob;

    [HttpPost("image")]
    public async Task<IActionResult> Image(IFormFile file)
    {
        if(SessionAuthFilter.Role(HttpContext)!="Organiser") return Forbid();
        if(file is null || file.Length==0) return BadRequest(new {message="Image file is required."});
        var url=await _blob.UploadAsync(file);
        return url is null
            ? StatusCode(503,new {message="Azure Blob Storage is not configured."})
            : Ok(new {url});
    }
}
