using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public EventsController(RaceDayDbContext db) => _db = db;

    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<EventResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(string? search, string? type, DateTime? date)
    {
        var q = _db.Events.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.Name.Contains(search) || x.Location.Contains(search));
        if (!string.IsNullOrWhiteSpace(type)) q = q.Where(x => x.EventType == type);
        if (date.HasValue) q = q.Where(x => x.EventDate.Date == date.Value.Date);
        var data = await q.OrderBy(x => x.EventDate)
            .Select(x => new EventResponse(x.EventID, x.OrganiserID, x.Name, x.Description, x.EventDate, x.Location, x.Distance, x.EventType, x.BannerImageUrl))
            .ToListAsync();
        return Ok(data);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var e = await _db.Events.FindAsync(id);
        return e is null ? NotFound(new { message = "Event not found." }) : Ok(ToResponse(e));
    }

    [HttpPost]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> Create(EventRequest request)
    {
        if (!ValidEvent(request, out var error)) return BadRequest(new { message = error });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser") return Forbid();
        var e = new Event
        {
            OrganiserID = SessionAuthFilter.UserId(HttpContext)!.Value,
            Name = request.Name.Trim(), Description = request.Description.Trim(), EventDate = request.EventDate,
            Location = request.Location.Trim(), Distance = request.Distance, EventType = request.EventType.Trim(), BannerImageUrl = request.BannerImageUrl
        };
        _db.Events.Add(e); await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = e.EventID }, ToResponse(e));
    }

    [HttpPut("{id:int}")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> Update(int id, EventRequest request)
    {
        if (!ValidEvent(request, out var error)) return BadRequest(new { message = error });
        var e = await _db.Events.FindAsync(id);
        if (e is null) return NotFound(new { message = "Event not found." });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser" || e.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        e.Name = request.Name.Trim(); e.Description = request.Description.Trim(); e.EventDate = request.EventDate;
        e.Location = request.Location.Trim(); e.Distance = request.Distance; e.EventType = request.EventType.Trim(); e.BannerImageUrl = request.BannerImageUrl;
        await _db.SaveChangesAsync();
        return Ok(ToResponse(e));
    }

    [HttpDelete("{id:int}")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> Delete(int id)
    {
        var e = await _db.Events.FindAsync(id);
        if (e is null) return NotFound(new { message = "Event not found." });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser" || e.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        _db.Events.Remove(e); await _db.SaveChangesAsync(); return NoContent();
    }

    [HttpGet("{eventId:int}/categories")]
    public async Task<IActionResult> Categories(int eventId)
    {
        if (!await _db.Events.AnyAsync(x => x.EventID == eventId)) return NotFound(new { message = "Event not found." });
        var data = await _db.Categories.Where(x => x.EventID == eventId)
            .OrderBy(x => x.Name)
            .Select(x => new CategoryResponse(x.CategoryID, x.EventID, x.Name, x.Description)).ToListAsync();
        return Ok(data);
    }

    [HttpPost("{eventId:int}/categories")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> AddCategory(int eventId, CategoryRequest request)
    {
        var e = await _db.Events.FindAsync(eventId);
        if (e is null) return NotFound(new { message = "Event not found." });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser" || e.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name)) return BadRequest(new { message = "Category name is required." });
        if (await _db.Categories.AnyAsync(x => x.EventID == eventId && x.Name == request.Name.Trim()))
            return Conflict(new { message = "Category already exists for this event." });
        var c = new Category { EventID = eventId, Name = request.Name.Trim(), Description = request.Description?.Trim() };
        _db.Categories.Add(c); await _db.SaveChangesAsync();
        return Created($"/api/events/{eventId}/categories", new CategoryResponse(c.CategoryID, c.EventID, c.Name, c.Description));
    }

    [HttpPut("/categories/{id:int}")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> UpdateCategory(int id, CategoryRequest request)
    {
        var c = await _db.Categories.Include(x => x.Event).SingleOrDefaultAsync(x => x.CategoryID == id);
        if (c is null) return NotFound(new { message = "Category not found." });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser" || c.Event!.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        if (string.IsNullOrWhiteSpace(request.Name)) return BadRequest(new { message = "Category name is required." });
        if (await _db.Categories.AnyAsync(x => x.CategoryID != id && x.EventID == c.EventID && x.Name == request.Name.Trim()))
            return Conflict(new { message = "Category already exists for this event." });
        c.Name = request.Name.Trim(); c.Description = request.Description?.Trim();
        await _db.SaveChangesAsync();
        return Ok(new CategoryResponse(c.CategoryID, c.EventID, c.Name, c.Description));
    }

    [HttpDelete("/categories/{id:int}")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var c = await _db.Categories.Include(x => x.Event).SingleOrDefaultAsync(x => x.CategoryID == id);
        if (c is null) return NotFound(new { message = "Category not found." });
        if (SessionAuthFilter.Role(HttpContext) != "Organiser" || c.Event!.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        if (await _db.Enrolments.AnyAsync(x => x.CategoryID == id)) return Conflict(new { message = "Category cannot be deleted while enrolments exist." });
        _db.Categories.Remove(c); await _db.SaveChangesAsync(); return NoContent();
    }

    private static bool ValidEvent(EventRequest r, out string? error)
    {
        error = null;
        if (string.IsNullOrWhiteSpace(r.Name) || string.IsNullOrWhiteSpace(r.Description) || string.IsNullOrWhiteSpace(r.Location)) error = "Name, description and location are required.";
        else if (r.Distance <= 0) error = "Distance must be greater than zero.";
        else if (r.EventType is not ("Run" or "Walk" or "Cycle")) error = "EventType must be Run, Walk or Cycle.";
        return error is null;
    }

    private static EventResponse ToResponse(Event e) => new(e.EventID, e.OrganiserID, e.Name, e.Description, e.EventDate, e.Location, e.Distance, e.EventType, e.BannerImageUrl);
}
