using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/profile")]
[ServiceFilter(typeof(SessionAuthFilter))]
public class ProfileController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public ProfileController(RaceDayDbContext db) => _db = db;

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        var u = await _db.Users.FindAsync(id);
        return u is null ? NotFound() : Ok(new UserResponse(u.UserID,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }

    [HttpPut("me")]
    public async Task<IActionResult> Update(UpdateProfileRequest request)
    {
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        var u = await _db.Users.FindAsync(id);
        if (u is null) return NotFound();
        u.FirstName = request.FirstName;
        u.LastName = request.LastName;
        u.PhoneNumber = request.PhoneNumber;
        u.ProfilePictureUrl = request.ProfilePictureUrl;
        await _db.SaveChangesAsync();
        return Ok(new UserResponse(u.UserID,u.FirstName,u.LastName,u.Email,u.Role,u.PhoneNumber,u.ProfilePictureUrl));
    }
}
