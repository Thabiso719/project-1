using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/enrolments")]
[ServiceFilter(typeof(SessionAuthFilter))]
public class EnrolmentsController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public EnrolmentsController(RaceDayDbContext db) => _db = db;

    [HttpPost]
    public async Task<IActionResult> Create(EnrolmentRequest request)
    {
        if (SessionAuthFilter.Role(HttpContext) != "Participant") return Forbid();
        var participantId = SessionAuthFilter.UserId(HttpContext)!.Value;
        var category = await _db.Categories.SingleOrDefaultAsync(x => x.CategoryID == request.CategoryId && x.EventID == request.EventId);
        if (category is null || !await _db.Events.AnyAsync(x => x.EventID == request.EventId)) return NotFound(new { message = "Event or category not found." });
        if (await _db.Enrolments.AnyAsync(x => x.ParticipantID == participantId && x.EventID == request.EventId)) return Conflict(new { message = "Participant is already enrolled in this event." });
        var e = new Enrolment { ParticipantID = participantId, EventID = request.EventId, CategoryID = request.CategoryId, Status = "Pending" };
        _db.Enrolments.Add(e); await _db.SaveChangesAsync();
        return Created("/api/enrolments/my", new EnrolmentResponse(e.EnrolmentID, e.ParticipantID, e.EventID, e.CategoryID, e.EnrolmentDate, e.Status));
    }

    [HttpGet("my")]
    public async Task<IActionResult> My()
    {
        if (SessionAuthFilter.Role(HttpContext) != "Participant") return Forbid();
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        var data = await _db.Enrolments.Where(x => x.ParticipantID == id)
            .Select(x => new EnrolmentResponse(x.EnrolmentID, x.ParticipantID, x.EventID, x.CategoryID, x.EnrolmentDate, x.Status)).ToListAsync();
        return Ok(data);
    }

    [HttpGet("/api/events/{eventId:int}/enrolments")]
    public async Task<IActionResult> ForEvent(int eventId)
    {
        if (SessionAuthFilter.Role(HttpContext) != "Organiser") return Forbid();
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        if (!await _db.Events.AnyAsync(x => x.EventID == eventId)) return NotFound(new { message = "Event not found." });
        if (!await _db.Events.AnyAsync(x => x.EventID == eventId && x.OrganiserID == id)) return Forbid();
        var data = await _db.Enrolments.Where(x => x.EventID == eventId)
            .Select(x => new EnrolmentResponse(x.EnrolmentID, x.ParticipantID, x.EventID, x.CategoryID, x.EnrolmentDate, x.Status)).ToListAsync();
        return Ok(data);
    }

    [HttpPut("{id:int}/status")]
    public async Task<IActionResult> Status(int id, StatusRequest request)
    {
        if (SessionAuthFilter.Role(HttpContext) != "Organiser") return Forbid();
        if (request.Status is not ("Pending" or "Confirmed" or "Cancelled")) return BadRequest(new { message = "Status must be Pending, Confirmed or Cancelled." });
        var e = await _db.Enrolments.Include(x => x.Event).SingleOrDefaultAsync(x => x.EnrolmentID == id);
        if (e is null) return NotFound(new { message = "Enrolment not found." });
        if (e.Event!.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        e.Status = request.Status; await _db.SaveChangesAsync();
        return Ok(new EnrolmentResponse(e.EnrolmentID, e.ParticipantID, e.EventID, e.CategoryID, e.EnrolmentDate, e.Status));
    }
}
