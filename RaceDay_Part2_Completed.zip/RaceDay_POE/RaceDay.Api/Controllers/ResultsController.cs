using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/results")]
[ServiceFilter(typeof(SessionAuthFilter))]
public class ResultsController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    public ResultsController(RaceDayDbContext db) => _db = db;

    [HttpPost]
    public async Task<IActionResult> Create(ResultRequest request)
    {
        if (SessionAuthFilter.Role(HttpContext) != "Organiser") return Forbid();
        if (request.FinishingPosition <= 0 || request.FinishTime < TimeSpan.Zero) return BadRequest(new { message = "A valid finish time and position are required." });
        var e = await _db.Enrolments.Include(x => x.Event).SingleOrDefaultAsync(x => x.EnrolmentID == request.EnrolmentId);
        if (e is null) return NotFound(new { message = "Enrolment not found." });
        if (e.Event!.OrganiserID != SessionAuthFilter.UserId(HttpContext)) return Forbid();
        if (await _db.Results.AnyAsync(x => x.EnrolmentID == request.EnrolmentId)) return Conflict(new { message = "A result already exists for this enrolment." });
        var r = new Result { EnrolmentID = request.EnrolmentId, FinishTime = request.FinishTime, FinishingPosition = request.FinishingPosition };
        _db.Results.Add(r); await _db.SaveChangesAsync();
        return Created("/api/results/my", new ResultResponse(r.ResultID, r.EnrolmentID, r.FinishTime, r.FinishingPosition));
    }

    [HttpGet("my")]
    public async Task<IActionResult> My()
    {
        if (SessionAuthFilter.Role(HttpContext) != "Participant") return Forbid();
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        var data = await _db.Results.Include(x => x.Enrolment).Where(x => x.Enrolment!.ParticipantID == id)
            .Select(x => new ResultResponse(x.ResultID, x.EnrolmentID, x.FinishTime, x.FinishingPosition)).ToListAsync();
        return Ok(data);
    }

    [HttpGet("/api/events/{eventId:int}/results")]
    public async Task<IActionResult> EventResults(int eventId)
    {
        if (SessionAuthFilter.Role(HttpContext) != "Organiser") return Forbid();
        var id = SessionAuthFilter.UserId(HttpContext)!.Value;
        if (!await _db.Events.AnyAsync(x => x.EventID == eventId)) return NotFound(new { message = "Event not found." });
        if (!await _db.Events.AnyAsync(x => x.EventID == eventId && x.OrganiserID == id)) return Forbid();
        var data = await _db.Results.Include(x => x.Enrolment).Where(x => x.Enrolment!.EventID == eventId)
            .Select(x => new ResultResponse(x.ResultID, x.EnrolmentID, x.FinishTime, x.FinishingPosition)).ToListAsync();
        return Ok(data);
    }
}
