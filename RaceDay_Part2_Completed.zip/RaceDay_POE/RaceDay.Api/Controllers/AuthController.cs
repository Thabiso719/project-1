using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly RaceDayDbContext _db;
    private readonly PasswordService _passwords;
    public AuthController(RaceDayDbContext db, PasswordService passwords) { _db = db; _passwords = passwords; }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.FirstName) || string.IsNullOrWhiteSpace(request.LastName) || string.IsNullOrWhiteSpace(request.Email))
            return BadRequest(new { message = "First name, last name and email are required." });
        if (request.Password is null || request.Password.Length < 8) return BadRequest(new { message = "Password must contain at least 8 characters." });
        if (request.Role is not ("Organiser" or "Participant")) return BadRequest(new { message = "Role must be Organiser or Participant." });
        var email = request.Email.Trim().ToLowerInvariant();
        if (await _db.Users.AnyAsync(x => x.Email == email)) return Conflict(new { message = "Email is already registered." });
        var user = new User { FirstName = request.FirstName.Trim(), LastName = request.LastName.Trim(), Email = email, PasswordHash = _passwords.Hash(request.Password), Role = request.Role, PhoneNumber = request.PhoneNumber?.Trim() };
        _db.Users.Add(user); await _db.SaveChangesAsync();
        return Created("/api/profile/me", ToResponse(user));
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var user = await _db.Users.SingleOrDefaultAsync(x => x.Email == request.Email.Trim().ToLowerInvariant());
        if (user is null || !_passwords.Verify(request.Password, user.PasswordHash)) return Unauthorized(new { message = "Invalid email or password." });
        HttpContext.Session.SetInt32("UserId", user.UserID);
        HttpContext.Session.SetString("Role", user.Role);
        return Ok(ToResponse(user));
    }

    [HttpPost("logout")]
    [ServiceFilter(typeof(SessionAuthFilter))]
    public IActionResult Logout() { HttpContext.Session.Clear(); return NoContent(); }

    private static UserResponse ToResponse(User u) => new(u.UserID, u.FirstName, u.LastName, u.Email, u.Role, u.PhoneNumber, u.ProfilePictureUrl);
}
