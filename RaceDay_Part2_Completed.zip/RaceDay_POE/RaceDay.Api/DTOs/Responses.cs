namespace RaceDay.Api.DTOs;

public record UserResponse(int UserID, string FirstName, string LastName, string Email, string Role, string? PhoneNumber, string? ProfilePictureUrl);
public record EventResponse(int EventID, int OrganiserID, string Name, string Description, DateTime EventDate, string Location, decimal Distance, string EventType, string? BannerImageUrl);
public record CategoryResponse(int CategoryID, int EventID, string Name, string? Description);
public record EnrolmentResponse(int EnrolmentID, int ParticipantID, int EventID, int CategoryID, DateTime EnrolmentDate, string Status);
public record ResultResponse(int ResultID, int EnrolmentID, TimeSpan FinishTime, int FinishingPosition);
