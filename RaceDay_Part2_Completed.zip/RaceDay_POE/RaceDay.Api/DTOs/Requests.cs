namespace RaceDay.Api.DTOs;

public record RegisterRequest(string FirstName, string LastName, string Email, string Password, string Role, string? PhoneNumber);
public record LoginRequest(string Email, string Password);
public record UpdateProfileRequest(string FirstName, string LastName, string? PhoneNumber, string? ProfilePictureUrl);
public record EventRequest(string Name, string Description, DateTime EventDate, string Location, decimal Distance, string EventType, string? BannerImageUrl);
public record CategoryRequest(string Name, string? Description);
public record EnrolmentRequest(int EventId, int CategoryId);
public record StatusRequest(string Status);
public record ResultRequest(int EnrolmentId, TimeSpan FinishTime, int FinishingPosition);
