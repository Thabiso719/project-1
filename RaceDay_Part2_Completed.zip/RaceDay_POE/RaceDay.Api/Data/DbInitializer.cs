using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Api.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(RaceDayDbContext db, PasswordService passwords)
    {
        if (db.Database.IsSqlServer()) await db.Database.MigrateAsync();
        if (await db.Users.AnyAsync()) return;

        var organiser1 = new User { FirstName = "Thabo", LastName = "Mokoena", Email = "thabo.organiser@raceday.co.za", PasswordHash = passwords.Hash("RaceDay!2026"), Role = "Organiser", PhoneNumber = "0711111111" };
        var organiser2 = new User { FirstName = "Nomsa", LastName = "Dlamini", Email = "nomsa.organiser@raceday.co.za", PasswordHash = passwords.Hash("RaceDay!2026"), Role = "Organiser", PhoneNumber = "0722222222" };
        var participant1 = new User { FirstName = "Sipho", LastName = "Nkosi", Email = "sipho.participant@raceday.co.za", PasswordHash = passwords.Hash("RaceDay!2026"), Role = "Participant", PhoneNumber = "0733333333" };
        var participant2 = new User { FirstName = "Lerato", LastName = "Molefe", Email = "lerato.participant@raceday.co.za", PasswordHash = passwords.Hash("RaceDay!2026"), Role = "Participant", PhoneNumber = "0744444444" };
        db.Users.AddRange(organiser1, organiser2, participant1, participant2);
        await db.SaveChangesAsync();

        var e1 = new Event { OrganiserID = organiser1.UserID, Name = "Johannesburg City Run", Description = "A road running event through Johannesburg.", EventDate = new DateTime(2027, 3, 14, 7, 0, 0), Location = "Johannesburg, Gauteng", Distance = 21.10m, EventType = "Run" };
        var e2 = new Event { OrganiserID = organiser1.UserID, Name = "Soweto Community Walk", Description = "A community walking event promoting health and fitness.", EventDate = new DateTime(2027, 4, 18, 8, 0, 0), Location = "Soweto, Gauteng", Distance = 10m, EventType = "Walk" };
        var e3 = new Event { OrganiserID = organiser2.UserID, Name = "Pretoria Cycle Challenge", Description = "A cycling event for recreational and competitive cyclists.", EventDate = new DateTime(2027, 5, 9, 6, 30, 0), Location = "Pretoria, Gauteng", Distance = 40m, EventType = "Cycle" };
        db.Events.AddRange(e1, e2, e3);
        await db.SaveChangesAsync();

        var c1 = new Category { EventID = e1.EventID, Name = "Under 20", Description = "Participants younger than 20 years." };
        var c2 = new Category { EventID = e1.EventID, Name = "Senior", Description = "Open senior category." };
        var c3 = new Category { EventID = e1.EventID, Name = "Veteran", Description = "Veteran participant category." };
        var c4 = new Category { EventID = e2.EventID, Name = "10 km Open", Description = "Open 10 kilometre walking category." };
        var c5 = new Category { EventID = e2.EventID, Name = "Family Walk", Description = "Category for family participants." };
        var c6 = new Category { EventID = e3.EventID, Name = "40 km Open", Description = "Open 40 kilometre cycling category." };
        var c7 = new Category { EventID = e3.EventID, Name = "Junior", Description = "Junior cycling category." };
        db.Categories.AddRange(c1, c2, c3, c4, c5, c6, c7);
        await db.SaveChangesAsync();

        var en1 = new Enrolment { ParticipantID = participant1.UserID, EventID = e1.EventID, CategoryID = c2.CategoryID, Status = "Confirmed" };
        var en2 = new Enrolment { ParticipantID = participant2.UserID, EventID = e1.EventID, CategoryID = c2.CategoryID, Status = "Confirmed" };
        var en3 = new Enrolment { ParticipantID = participant1.UserID, EventID = e2.EventID, CategoryID = c4.CategoryID, Status = "Confirmed" };
        var en4 = new Enrolment { ParticipantID = participant2.UserID, EventID = e3.EventID, CategoryID = c6.CategoryID, Status = "Pending" };
        db.Enrolments.AddRange(en1, en2, en3, en4);
        await db.SaveChangesAsync();

        db.Results.AddRange(
            new Result { EnrolmentID = en1.EnrolmentID, FinishTime = new TimeSpan(2, 14, 32), FinishingPosition = 47 },
            new Result { EnrolmentID = en2.EnrolmentID, FinishTime = new TimeSpan(2, 21, 45), FinishingPosition = 68 });
        await db.SaveChangesAsync();
    }
}
