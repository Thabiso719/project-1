using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;

namespace RaceDay.Tests;

public class RaceDayApiFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.ConfigureServices(services =>
        {
            var descriptor = services.SingleOrDefault(d => d.ServiceType == typeof(DbContextOptions<RaceDayDbContext>));
            if (descriptor != null) services.Remove(descriptor);
            services.AddDbContext<RaceDayDbContext>(options => options.UseInMemoryDatabase($"RaceDayTests-{Guid.NewGuid()}"));
        });
    }
}

public class ApiIntegrationTests : IClassFixture<RaceDayApiFactory>
{
    private readonly RaceDayApiFactory _factory;
    public ApiIntegrationTests(RaceDayApiFactory factory) => _factory = factory;

    [Fact]
    public async Task Register_And_Login_Succeeds()
    {
        using var client = _factory.CreateClient();
        var email = $"participant-{Guid.NewGuid():N}@example.com";
        var register = await client.PostAsJsonAsync("/api/auth/register", new { firstName = "Test", lastName = "Participant", email, password = "RaceDay!2026", role = "Participant", phoneNumber = "0710000000" });
        Assert.Equal(HttpStatusCode.Created, register.StatusCode);

        var login = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "RaceDay!2026" });
        Assert.Equal(HttpStatusCode.OK, login.StatusCode);
    }

    [Fact]
    public async Task Login_WithWrongPassword_IsRejected()
    {
        using var client = _factory.CreateClient();
        var email = $"wrong-{Guid.NewGuid():N}@example.com";
        await client.PostAsJsonAsync("/api/auth/register", new { firstName = "Test", lastName = "User", email, password = "RaceDay!2026", role = "Participant", phoneNumber = "0710000000" });
        var response = await client.PostAsJsonAsync("/api/auth/login", new { email, password = "WrongPassword" });
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Participant_Cannot_Create_Event()
    {
        using var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true });
        var email = $"participant-{Guid.NewGuid():N}@example.com";
        await client.PostAsJsonAsync("/api/auth/register", new { firstName = "Test", lastName = "Participant", email, password = "RaceDay!2026", role = "Participant", phoneNumber = "0710000000" });
        await client.PostAsJsonAsync("/api/auth/login", new { email, password = "RaceDay!2026" });

        var response = await client.PostAsJsonAsync("/api/events", new { name = "Should Fail", description = "Participant cannot create", eventDate = DateTime.UtcNow.AddDays(30), location = "Johannesburg", distance = 10.0m, eventType = "Run", bannerImageUrl = (string?)null });
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Organiser_Can_Create_Event()
    {
        using var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true });
        var email = $"organiser-{Guid.NewGuid():N}@example.com";
        await client.PostAsJsonAsync("/api/auth/register", new { firstName = "Test", lastName = "Organiser", email, password = "RaceDay!2026", role = "Organiser", phoneNumber = "0710000000" });
        await client.PostAsJsonAsync("/api/auth/login", new { email, password = "RaceDay!2026" });

        var response = await client.PostAsJsonAsync("/api/events", new { name = "Test Run", description = "Integration test event", eventDate = DateTime.UtcNow.AddDays(30), location = "Johannesburg", distance = 21.1m, eventType = "Run", bannerImageUrl = (string?)null });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
    }

    [Fact]
    public async Task Participant_Can_Enrol_And_View_Enrolment()
    {
        using var organiser = _factory.CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true });
        var organiserEmail = $"org-{Guid.NewGuid():N}@example.com";
        await organiser.PostAsJsonAsync("/api/auth/register", new { firstName = "Org", lastName = "User", email = organiserEmail, password = "RaceDay!2026", role = "Organiser", phoneNumber = "0710000000" });
        await organiser.PostAsJsonAsync("/api/auth/login", new { email = organiserEmail, password = "RaceDay!2026" });
        var eventResponse = await organiser.PostAsJsonAsync("/api/events", new { name = "Enrolment Test", description = "Integration test", eventDate = DateTime.UtcNow.AddDays(30), location = "Soweto", distance = 10.0m, eventType = "Walk", bannerImageUrl = (string?)null });
        var eventJson = await eventResponse.Content.ReadFromJsonAsync<EventCreated>();
        var categoryResponse = await organiser.PostAsJsonAsync($"/api/events/{eventJson!.eventID}/categories", new { name = "Open", description = "Open category" });
        var categoryJson = await categoryResponse.Content.ReadFromJsonAsync<CategoryCreated>();

        using var participant = _factory.CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true });
        var participantEmail = $"part-{Guid.NewGuid():N}@example.com";
        await participant.PostAsJsonAsync("/api/auth/register", new { firstName = "Part", lastName = "User", email = participantEmail, password = "RaceDay!2026", role = "Participant", phoneNumber = "0710000000" });
        await participant.PostAsJsonAsync("/api/auth/login", new { email = participantEmail, password = "RaceDay!2026" });
        var enrol = await participant.PostAsJsonAsync("/api/enrolments", new { eventId = eventJson.eventID, categoryId = categoryJson!.categoryID });
        Assert.Equal(HttpStatusCode.Created, enrol.StatusCode);
        var mine = await participant.GetAsync("/api/enrolments/my");
        Assert.Equal(HttpStatusCode.OK, mine.StatusCode);
    }

    private sealed record EventCreated(int eventID);
    private sealed record CategoryCreated(int categoryID);
}
