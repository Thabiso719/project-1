using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class PasswordServiceTests
{
    [Fact]
    public void HashAndVerify_Work()
    {
        var service = new PasswordService();
        var hash = service.Hash("RaceDay!2026");
        Assert.NotEqual("RaceDay!2026", hash);
        Assert.StartsWith("PBKDF2-SHA256$", hash);
        Assert.True(service.Verify("RaceDay!2026", hash));
        Assert.False(service.Verify("WrongPassword", hash));
    }
}
