using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class ApiPlanTests
{
    [Theory]
    [InlineData("Run")]
    [InlineData("Walk")]
    [InlineData("Cycle")]
    public void EventTypes_AreSupported(string type) => Assert.Contains(type, new[] { "Run", "Walk", "Cycle" });

    [Fact]
    public void PasswordHash_IsNotPlainText()
    {
        var service = new PasswordService();
        var hash = service.Hash("secret");
        Assert.NotEqual("secret", hash);
        Assert.StartsWith("PBKDF2-SHA256$", hash);
    }
}
