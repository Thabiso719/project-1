# RaceDay Part 2 Submission Checklist

## Before submitting

- [ ] Open `RaceDay.sln` in Visual Studio 2022.
- [ ] Confirm .NET 8 SDK is installed.
- [ ] Configure SQL Server connection in `RaceDay.Api/appsettings.json` or environment variables.
- [ ] Run `dotnet restore`.
- [ ] Run `dotnet build` successfully.
- [ ] Run `dotnet test --configuration Release` successfully.
- [ ] Run the API and open Swagger.
- [ ] Test registration and login for both roles.
- [ ] Test organiser event/category/enrolment/result functions.
- [ ] Test participant enrolment and own results.
- [ ] Capture genuine Swagger/API screenshots required by the lecturer.
- [ ] Push the project to the student's own GitHub repository.
- [ ] Make at least 20 meaningful Part 2 commits from the student's own account.
- [ ] Confirm GitHub Actions is green.
- [ ] Capture the genuine green workflow screenshot.
- [ ] Record the student's own unlisted YouTube demonstration with voiceover.
- [ ] Add the real GitHub and YouTube links to the README/ARC.
- [ ] Include the required AI-use disclosure and ensure the student understands/adapts the implementation.
